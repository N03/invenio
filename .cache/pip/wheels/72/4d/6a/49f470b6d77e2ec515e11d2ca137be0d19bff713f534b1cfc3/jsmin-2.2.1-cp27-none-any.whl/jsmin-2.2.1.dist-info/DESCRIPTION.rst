=====
jsmin
=====

JavaScript minifier.

Usage
=====

.. code:: python

 from jsmin import jsmin
 with open('myfile.js') as js_file:
     minified = jsmin(js_file.read())

You can run it as a commandline tool also::

  python -m jsmin myfile.js

NB: ``jsmin`` makes no attempt to be compatible with
`ECMAScript 6 / ES.next / Harmony <http://wiki.ecmascript.org/doku.php?id=harmony:specification_drafts>`_.
The current maintainer does not intend to add ES6-compatibility. If you would
like to take over maintenance and update ``jsmin`` for ES6, please contact
`Tikitu de Jager <mailto:tikitu+jsmin@logophile.org>`_. Pull requests are also
welcome, of course, but my time to review them is somewhat limited these days.

If you're using ``jsmin`` on ES6 code, though, you might find the ``quote_chars``
parameter useful:

.. code:: python

 from jsmin import jsmin
 with open('myfile.js') as js_file:
     minified = jsmin(js_file.read(), quote_chars="'\"`")


Where to get it
===============

* install the package `from pypi <https://pypi.python.org/pypi/jsmin/>`_
* get the latest release `from latest-release on github <https://github.com/tikitu/jsmin/tree/latest-release/jsmin>`_
* get the development version `from master on github <https://github.com/tikitu/jsmin/>`_

Contributing
============

`Issues <https://github.com/tikitu/jsmin/issues>`_ and `Pull requests <https://github.com/tikitu/jsmin/pulls>`_
will be gratefully received on Github. The project used to be hosted
`on bitbucket <https://bitbucket.org/dcs/jsmin/>`_ and old issues can still be
found there.

If possible, please make separate pull requests for tests and for code: tests will be added to the `latest-release` branch while code will go to `master`.

Unless you request otherwise, your Github identity will be added to the contributor's list below; if you prefer a
different name feel free to add it in your pull request instead. (If you prefer not to be mentioned you'll have to let
the maintainer know somehow.)

Build/test status
=================

Both branches are tested with Travis: https://travis-ci.org/tikitu/jsmin

The `latest-release` branch (the version on PyPI plus any new tests) is tested against CPython 2.6, 2.7, 3.2, and 3.3.
Currently:

.. image:: https://travis-ci.org/tikitu/jsmin.png?branch=latest-release

If that branch is failing that means there's a new test that fails on *the latest released version on pypi*, with no fix yet
released.

The `master` branch (development version, might be ahead of latest released version) is tested against CPython 2.6, 2.7, 3.2, and
3.3. Currently:

.. image:: https://travis-ci.org/tikitu/jsmin.png?branch=master

If `master` is failing don't use it, but as long as `latest-release` is passing the pypi release should be ok.

Contributors (chronological commit order)
=========================================

* `Dave St.Germain <https://bitbucket.org/dcs>`_ (original author)
* `Hans weltar <https://bitbucket.org/hansweltar>`_
* `Tikitu de Jager <mailto:tikitu+jsmin@logophile.org>`_ (current maintainer)
* https://bitbucket.org/rennat
* `Nick Alexander <https://bitbucket.org/ncalexan>`_
* `Gennady Kovshenin <https://github.com/soulseekah>`_
* `Matt Molyneaux <https://github.com/moggers87>`_

Changelog
=========

v2.2.1 (2016-03-06) Tikitu de Jager
-----------------------------------

- Fix #14: Infinite loop on `return x / 1;`

v2.2.0 (2015-12-19) Tikitu de Jager
-----------------------------------

- Merge #13: Preserve "loud comments" starting with `/*!`

  These are commonly used for copyright notices, and are preserved by various
  other minifiers (e.g. YUI Compressor).

v2.1.6 (2015-10-14) Tikitu de Jager
-----------------------------------

- Fix #12: Newline following a regex literal should not be elided.

v2.1.5 (2015-10-11) Tikitu de Jager
-----------------------------------

- Fix #9: Premature end of statement caused by multi-line comment not
  adding newline.

- Fix #10: Removing multiline comment separating tokens must leave a space.

- Refactor comment handling for maintainability.

v2.1.4 (2015-08-23) Tikitu de Jager
-----------------------------------

- Fix #6: regex literal matching comment was not correctly matched.

- Refactor regex literal handling for robustness.

v2.1.3 (2015-08-09) Tikitu de Jager
-----------------------------------

- Reset issue numbering: issues live in github from now on.

- Fix #1: regex literal was not recognised when occurring directly after `{`.

v2.1.2 (2015-07-12) Tikitu de Jager
-----------------------------------

- Issue numbers here and below refer to the bitbucket repository.

- Fix #17: bug when JS starts with comment then literal regex.

v2.1.1 (2015-02-14) Tikitu de Jager
-----------------------------------

- Fix #16: bug returning a literal regex containing escaped forward-slashes.

v2.1.0 (2014-12-24) Tikitu de Jager
-----------------------------------

- First changelog entries; see README.rst for prior contributors.

- Expose quote_chars parameter to provide just enough unofficial Harmony
  support to be useful.



