SQLAlchemy-Utils
----------------

Various utility functions and custom data types for SQLAlchemy.


